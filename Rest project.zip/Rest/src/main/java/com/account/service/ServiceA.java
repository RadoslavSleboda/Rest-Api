package com.account.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.account.account.Account;
import com.account.repository.RepositoryA;

@Service
public class ServiceA {
	@Autowired
	
	RepositoryA repository;
	public Account getAccountByName(String name) {
		return repository.findById(name).get();
	}
	public List<Account> getAllAccounts() {
		List <Account> accounts = new ArrayList<Account>();
		repository.findAll().forEach(account -> accounts.add(account));
		return accounts;
	}
	public void saveOrUpdate(Account account) {
		repository.save(account);
	}

	public void deleteAccountByName(String name) {
		repository.deleteById(name);
	}

}
