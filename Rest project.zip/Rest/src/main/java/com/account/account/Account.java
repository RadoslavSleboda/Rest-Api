package com.account.account;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Account {
	@Id
	@Column
	private String name;
	@Column
	private int pin;
	@Column
	private int money;
	@Column
	private int annualDebtPayment;
	@Column
	private int debtLength;
	


	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	public int getAnnualDebtPayment() {
		return annualDebtPayment;
	}
	public void setAnnualDebtPayment(int annualDebtPayment) {
		this.annualDebtPayment = annualDebtPayment;
	}
	public int getDebtLength() {
		return debtLength;
	}
	public void setDebtLength(int debtLength) {
		this.debtLength = debtLength;
	}
	

}
